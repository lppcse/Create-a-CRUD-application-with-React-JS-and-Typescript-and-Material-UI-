import React, { useEffect, useState } from 'react';
import Service from './Components/Axios/Service';
import './App.css';


// MUI DATA GRID
import {
  DataGrid
} from '@mui/x-data-grid';
import { DataGridPro } from '@mui/x-data-grid-pro';
import Button from '@mui/material/Button';

function App() {

  interface dataType {
    "id": number;
    "name": string;
    "username": string;
    "email": string;
    "address": {
      "street": string;
      "suite": string;
      "city": string;
      "zipcode": string;
      "geo": {
        "lat": string;
        "lng": string;
      }
    },
    "phone": string;
    "website": string;
    "company": {
      "name": string;
      "catchPhrase": string;
      "bs": string;
    }
  }

  interface dataItemType {
    id: number;
    name: string;
    username: string;
    email: string;
    delete: string;
  }

  const initialData = [{
    "id": 1,
    "name": "Leanne Graham",
    "username": "Bret",
    "email": "Sincere@april.biz",
    "address": {
      "street": "Kulas Light",
      "suite": "Apt. 556",
      "city": "Gwenborough",
      "zipcode": "92998-3874",
      "geo": {
        "lat": "-37.3159",
        "lng": "81.1496"
      }
    },
    "phone": "1-770-736-8031 x56442",
    "website": "hildegard.org",
    "company": {
      "name": "Romaguera-Crona",
      "catchPhrase": "Multi-layered client-server neural-net",
      "bs": "harness real-time e-markets"
    }
  }
  ]

  const initialDataItem = [
    {
      'id': 1,
      'name': 'xyz',
      'username': 'xyz@',
      'email': 'xyz@gmail',
      'delete': 'DELETE'
    }
  ]
  const [data, setData] = useState(initialData);
  const [dataItem, setDataItem] = useState(initialDataItem);

  const userDataFetch = async () => {
    const res = await Service('http://localhost:5000/');
    //setData((data: dataType[]) => res);

    const dataItemData = res.map((item: any) => {
      return (
        {
          'id': item.id,
          'name': item.name,
          'username': item.username,
          'email': item.email,
          'delete': 'DELETE'
        }
      )
    })
  
    setDataItem((dataItem) => dataItemData);
  }

  useEffect(() => {
    userDataFetch();
  }, []);


 
  const columns = [
    { field: 'id', headerName: 'ID', width: 180, editable: true },
    { field: 'name', headerName: 'NAME', width: 180, editable: true },
    { field: 'username', headerName: 'USERNAME', width: 180, editable: true },
    { field: 'email', headerName: 'EMAIL', width: 180, editable: true },
    { field: 'delete', headerName: 'DELETE COLUMN', width: 180, editable: false }
  ];
  let count = 0;
  const createRandomRow = () => {
    count += 1;
    return { id: count, name: '', username: '', email: '', delete: '' };
  };

  const handleAddRow = () => {
    setDataItem((dataItem: dataItemType[]) => [...dataItem, createRandomRow()]);
  };

  const handleDeleteRow = () => { 
   const filterData = dataItem.filter((item) => item.id !== dataItem.length);
   setDataItem((dataItem) => filterData);
  }

  return (
    <div className="Appk">

      <div style={{ display: 'flex', height: '100vh' }}>
        <div style={{ flexGrow: 1 }}>
          <DataGridPro
            rows={dataItem}
            columns={columns}
            editMode="row"
          />



          
        </div></div>
        <Button size="small" onClick={handleAddRow}>
            Add a row
          </Button>

          <Button size="small" onClick={handleDeleteRow}>
          Delete a row
        </Button>
    </div>
  );
}

export default App;
