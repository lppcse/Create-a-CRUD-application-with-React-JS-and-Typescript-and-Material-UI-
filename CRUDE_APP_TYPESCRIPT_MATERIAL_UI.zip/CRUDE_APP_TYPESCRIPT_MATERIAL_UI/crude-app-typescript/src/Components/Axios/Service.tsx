import axios  from 'axios';
import { createContext } from 'react';

const fetchAPI = async() => {
    try {

        
        const response = await axios.get('https://jsonplaceholder.typicode.com/users');

        if (!response) {
            //throw new Error(`HTTP error: ${response.status}`);
        }
        const { data }= response;
        console.log(JSON.stringify(data)+ 'datttttttttttttttttttttttttttttttta');
        return data;
    }
   catch(err){
        console.log(err);
   }
}


const Service = (props: any) => {
    return fetchAPI();
    
}

export default Service;  


